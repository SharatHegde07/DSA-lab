#include "6b.h"
stack* stack_initialize(int size)
{
//TODO
}

void stack_push(stack *ptr_stack, int key) 
{
//TODO
}

void stack_pop(stack *ptr_stack)
{
//TODO
}

int stack_is_empty(stack *ptr_stack)
{
//TODO
}

int stack_peek(stack *ptr_stack) 
{
//TODO
}

void stack_destroy(stack *ptr_stack) 
{
//TODO
}

void convert_infix_to_postfix(const char *source_infix,char *target_postfix)
{
//TODO
}
