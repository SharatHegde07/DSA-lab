#include "cll.h"
void position_insert(List* cll, int data, int pos)
{
//TODO
}

void position_delete(List* cll, int pos)
{
//TODO
}

int josephus(List* cll, int k)
{
//TODO
}


